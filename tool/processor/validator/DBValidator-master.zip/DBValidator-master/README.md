DBValidator
===========
[![Build Status](https://travis-ci.org/daniel-beard/DBValidator.png?branch=master)](https://travis-ci.org/daniel-beard/DBValidator)

General purpose validation framework for objective-c / iOS.

Supports adding validation rules to any keypath on an NSObject.

* http://danielbeard.io
* http://danielbeard.wordpress.com

Copyright (C) 2013 Daniel Beard
 
Distributed under [MIT License](http://opensource.org/licenses/mit-license.php)

![Image](http://i.imgur.com/xmKHY.png)
