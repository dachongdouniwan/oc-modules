//
//  DBDummyClass.h
//  DBValidator
//
//  Created by Daniel Beard on 11/05/13.
//  Copyright (c) 2013 Daniel Beard. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBDummyClass : NSObject

@property (nonatomic, copy) NSString *genericString;
@property (nonatomic, strong) NSNumber *genericNumber;

@end
