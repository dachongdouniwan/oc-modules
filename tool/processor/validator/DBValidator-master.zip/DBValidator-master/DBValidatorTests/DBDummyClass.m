//
//  DBDummyClass.m
//  DBValidator
//
//  Created by Daniel Beard on 11/05/13.
//  Copyright (c) 2013 Daniel Beard. All rights reserved.
//

#import "DBDummyClass.h"

@implementation DBDummyClass

@end
