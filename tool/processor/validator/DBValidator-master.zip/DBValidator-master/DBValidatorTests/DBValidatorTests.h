//
//  DBValidatorTests.h
//  DBValidatorTests
//
//  Created by Daniel Beard on 11/05/13.
//  Copyright (c) 2013 Daniel Beard. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DBValidatorTests : SenTestCase

@end
