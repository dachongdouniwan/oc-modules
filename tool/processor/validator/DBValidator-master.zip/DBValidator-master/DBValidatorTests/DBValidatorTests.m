//
//  DBValidatorTests.m
//  DBValidatorTests
//
//  Created by Daniel Beard on 11/05/13.
//  Copyright (c) 2013 Daniel Beard. All rights reserved.
//

#import "DBValidatorTests.h"

@implementation DBValidatorTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

@end
