//
//  User.m
//  Demo
//
//  Created by MaSong on 2017/8/9.
//  Copyright © 2017年 MaSong. All rights reserved.
//

#import "User.h"

@implementation User

@end
